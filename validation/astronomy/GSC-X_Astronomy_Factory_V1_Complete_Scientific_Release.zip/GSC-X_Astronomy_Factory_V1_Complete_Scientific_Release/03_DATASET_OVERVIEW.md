# Dataset Overview

The dataset contains JWST X1D spectra processed through the complete
Astronomy Factory V1 pipeline.

The release includes discovery, metadata audit, quality analysis,
fingerprinting, similarity analysis, graph clustering and feature extraction.
