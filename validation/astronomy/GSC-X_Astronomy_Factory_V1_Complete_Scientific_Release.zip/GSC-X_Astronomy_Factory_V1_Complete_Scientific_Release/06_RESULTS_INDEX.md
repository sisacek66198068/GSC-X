# Results Index

The validation generated CSV outputs covering:

- Discovery inventory
- Metadata summaries
- Configuration matrix
- Spectrum statistics
- Quality matrix
- Analysis manifest
- Target identity audit
- Spectral fingerprints
- Similarity matrices
- Graph clustering
- Threshold stability
- Spectral feature candidates
