# DOI and Project Links

Research Portal:
https://gds-gsc-x.com

GitHub GSC-X:
https://github.com/sisacek66198068/GSC-X

GitHub GDS:
https://github.com/sisacek66198068/GDS-framework

ORCID:
https://orcid.org/0009-0007-0409-6037

DOIs

GDS Framework
https://doi.org/10.5281/zenodo.20037474

GSC-X Framework
https://doi.org/10.5281/zenodo.20156104

Executive Kernel
https://doi.org/10.5281/zenodo.21264908
