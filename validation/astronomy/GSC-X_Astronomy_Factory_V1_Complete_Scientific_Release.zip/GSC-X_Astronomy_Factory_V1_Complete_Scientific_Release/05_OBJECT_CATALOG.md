# Scientific Object Catalog

Current confirmed targets observed in the validation include entries such as:

- alf Pic
- VHS-1256B
- GD 56
- BET PIC BACKGROUND

Each object will receive its own scientific profile in the complete publication.
