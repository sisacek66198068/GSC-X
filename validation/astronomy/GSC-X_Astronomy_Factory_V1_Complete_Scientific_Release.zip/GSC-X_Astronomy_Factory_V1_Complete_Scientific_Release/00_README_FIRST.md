# GSC-X Astronomy Factory V1 – Complete Scientific Release

This release package accompanies the Astronomy Factory V1 validation.

Contents
- Complete terminal summary
- Executive summary
- Dataset overview
- Validation overview
- Object catalog template
- Results index
- Output documentation
- Reproducibility notes
- DOI and project links

Status:
Current package is based on the exported validation summary and serves as the foundation for the full public scientific release.
